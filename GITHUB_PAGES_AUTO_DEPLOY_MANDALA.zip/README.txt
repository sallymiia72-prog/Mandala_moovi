АВТОМАТИЧЕСКАЯ ПУБЛИКАЦИЯ GITHUB PAGES

1. Распакуйте архив.
2. В репозитории Mandala_moovi загрузите папку .github целиком,
   чтобы путь был:
   .github/workflows/deploy-pages.yml
3. Откройте Settings → Pages.
4. В Source выберите GitHub Actions.
5. После этого каждое изменение index.html в ветке main
   автоматически запустит новую публикацию.
6. Проверять публикацию:
   Actions → Deploy Mandala to GitHub Pages.

Важно:
- Не используйте одновременно Deploy from a branch и GitHub Actions.
- Первая публикация обычно занимает 1–5 минут.
